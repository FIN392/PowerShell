
class Log {
    [string] $FileName
    [string] $Type

    Log ( [string] $FileName, [string] $Type ) {

        # Create folder if don't exist
        if ( !(Test-Path -Path ( Split-Path -Path $FileName ) ) ) {
            New-Item -Path ( Split-Path -Path $FileName ) -ItemType 'directory'
            Write-Debug ( 'Folder "' + ( Split-Path -Path $FileName ) + '" created' )
        }

        # Create file if don't exist
        if ( !(Test-Path -Path $FileName ) ) {
            New-Item -Path ( Split-Path -Path $FileName ) -Name ( Split-Path -Path $FileName -Leaf ) -ItemType 'file'
            Write-Debug ( 'File "' + ( Split-Path -Path $FileName -Leaf ) + '" created' )
        }

        $this.FileName = ( Resolve-Path $FileName )
        $this.Type = $Type

    }

    Write(){

        Write-Host  'x' 

        Write-Debug  'x' 
    }

    
}



