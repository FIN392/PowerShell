# TEST
$DebugPreference = 'SilentlyContinue'
$DebugPreference = 'Continue'

Write-Debug 'ON'

. 'D:\OneDrive\_Documentos JLF\Escritorio\xPowerShell\xLog.ps1'

$Log = [Log]::new( '.\Logs\Logfile.txt', 'TXT' )

$Log.Write 



