# TEST


Using Module "D:\OneDrive\_Documentos JLF\Escritorio\xPowerShell\PSx.psm1"

 
Write-Log '.\LogFile.txt'CSV  DEBUG 'This is the text'




