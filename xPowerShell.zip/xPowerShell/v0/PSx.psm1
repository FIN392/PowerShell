





# Write-Log [-LogFile] <string> [-LogType] {CSV | XML | HTML} [-EntryType] {DEBUG | INFO | WARN | ERROR | FATAL} [-Message] <string> [<CommonParameters>]
function Write-Log {
<# 
    .SYNOPSIS
        This is the synopsis

    .DESCRIPTION
        This is the description

    .PARAMETER LogFile
        This is LogFile description
        Example: C:\logFile.txt

    .PARAMETER LogType
        This is LogType description
            CSV     Designates fine-grained informational events that are most useful to debug an application.
            HTML    Designates informational messages that highlight the progress of the application at coarse-grained level.
            XML     Designates potentially harmful situations.
        Default value is CSV

    .PARAMETER EntryType
        This is EntryType description
            DEBUG   Designates fine-grained informational events that are most useful to debug an application.
            INFO    Designates informational messages that highlight the progress of the application at coarse-grained level.
            WARN    Designates potentially harmful situations.
            ERROR   Designates error events that might still allow the application to continue running.
            FATAL   Designates very severe error events that will presumably lead the application to abort.
        Default value is DEBUG

    .PARAMETER Message
        This is Message description

    .INPUTS
        None.

    .OUTPUTS
        None.

    .EXAMPLE
        .\Write-Log ".\Logs\xxxxx.csv" CSV INFO "This is a example"
        This example tests the i: drive, generates files under i:\support, uses a maximum of 3GB disk space on i: drive.
        It runs a single thread, runs for 3 cycles, uses largest file = 100MB (1 order of magnitude below 3GB entered), smallest file = 10MB (1 order of magnitude below largest file)

    .EXAMPLE
        .\Write-Log ".\Logs\xxxxx.xml" XML ERROR "This is an error!!!"
        This example tests the i: drive, generates files under i:\support, uses a maximum of 11GB disk space on i: drive, uses a maximum of 8 threads, runs for 5 cycles, and uses SamllestFile 100MB.

    .EXAMPLE
        .\Write-Log ".\Logs\xxxxx.html" HTML DEBUG "This is debug comment"
        This example tests the i: drive, generates files under i:\support, uses a maximum of 11GB disk space on i: drive, uses a maximum of 8 threads, runs for 5 cycles, and uses SamllestFile 100MB.

    .LINK
        https://superwidgets.wordpress.com/category/powershell/

    .NOTES
        v0.1 - 2020-03-31 - fin392@gmail.com - Initial version
#>

    # [CmdletBinding()]
    param(
        [Parameter (Mandatory=$true, Position=1,HelpMessage="Full file path of log file")][String]$LogFile,
        [Parameter (Mandatory=$false,Position=2,HelpMessage="Type of log file: CSV | HTML | XML")][String]$LogType = 'CSV',
        [Parameter (Mandatory=$false,Position=3,HelpMessage="Type of entry: DEBUG | INFO | WARN | ERROR | FATAL")][String]$EntryType = 'INFO',
        [Parameter (Mandatory=$false,Position=4,HelpMessage="Message text")][String]$Message = '***'
    )

    write-host
    write-host ('$LogFile.....: ' + (Resolve-Path $LogFile))
    write-host ('$LogType.....: ' + $LogType)
    write-host ('$EntryType...: ' + $EntryType)
    write-host ('$Message... .: ' + $Message)
    write-host

    write-host ('"' + (Get-Date -format 'yyyy.MM.dd hh:mm:ss.ffff') + '","' + 'CSV' + '","' + $Message + '"')
    write-host ('"' + (Get-Date -format 'yyyy.MM.dd hh:mm:ss.ffff') + '","' + 'HTML' + '","' + $Message + '"')
    write-host ('"' + (Get-Date -format 'yyyy.MM.dd hh:mm:ss.ffff') + '","' + 'XML' + '","' + $Message + '"')

}
Export-ModuleMember -Function Write-Log




# Limit-Log [-LogFile] <string> [-RetentionDays] <Int32> [<CommonParameters>]

